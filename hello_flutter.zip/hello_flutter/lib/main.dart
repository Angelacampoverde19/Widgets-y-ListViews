import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // número de tabs
      child: Scaffold(
        appBar: AppBar(
          title: Text('Mi Aplicación Flutter'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Inicio'),
              Tab(text: 'Productos'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            MainWidget(),
            ProductList(),
          ],
        ),
      ),
    );
  }
}

class MainWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            '¡Bienvenido a mi aplicación Flutter!',
            style: TextStyle(fontSize: 20.0),
          ),
          SizedBox(height: 16.0),
          FlutterLogo(size: 100.0),
        ],
      ),
    );
  }
}

class Product {
  final String name;
  final String description;
  final String imageUrl;

  Product({
    required this.name,
    required this.description,
    required this.imageUrl,
  });
}

class ProductList extends StatelessWidget {
  final List<Product> products = [
    Product(
      name: 'Producto 1',
      description: 'Computadora',
      imageUrl: 'https://cdn5.dibujos.net/dibujos/pintados/201553/ordenador-de-sobremesa-la-casa-la-habitacion-10339873.jpg',
    ),
    Product(
      name: 'Producto 2',
      description: 'Coomputadora',
      imageUrl: 'https://cdn5.dibujos.net/dibujos/pintados/201553/ordenador-de-sobremesa-la-casa-la-habitacion-10339873.jpg',
    ),
    // Se agrego una lista de productos
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: products.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage(products[index].imageUrl),
          ),
          title: Text(products[index].name),
          subtitle: Text(products[index].description),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProductDetailsScreen(product: products[index]),
              ),
            );
          },
        );
      },
    );
  }
}

class ProductDetailsScreen extends StatelessWidget {
  final Product product;

  ProductDetailsScreen({required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product.name),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(product.imageUrl, height: 200.0, width: double.infinity, fit: BoxFit.cover),
            SizedBox(height: 16.0),
            Text(
              'Descripción:',
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
            Text(product.description),
            // Se puede agregar mas informacion o caracteristicas
          ],
        ),
      ),
    );
  }
}
